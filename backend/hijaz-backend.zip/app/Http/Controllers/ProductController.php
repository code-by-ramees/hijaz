<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Product;
use Database\Seeders\ProductSeeder;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function index()
    {
        return response()->json(Product::all()->values());
    }

    public function store(Request $request)
    {
        // Validate all non-file fields
        $request->validate([
            'category'      => 'required|string',
            'name'          => 'required|string',
            'subtitle'      => 'nullable|string',
            'description'   => 'nullable|string',
            'price'         => 'required|numeric',
            'originalPrice' => 'nullable|numeric',
            'badge'         => 'nullable|string',
            'rating'        => 'nullable|numeric',
            'reviews'       => 'nullable|integer',
            // image can be either an uploaded file or a string path
            'image'         => 'nullable',
        ]);

        $data = $request->only([
            'category', 'name', 'subtitle', 'description',
            'price', 'badge', 'rating', 'reviews',
        ]);

        // Handle image: file upload takes priority over string path
        if ($request->hasFile('image')) {
            $file     = $request->file('image');
            $filename = uniqid('product_') . '.' . $file->getClientOriginalExtension();
            $dest     = public_path('images/products');

            if (!is_dir($dest)) {
                mkdir($dest, 0775, true);
            }

            $file->move($dest, $filename);
            $data['image'] = '/images/products/' . $filename;
        } elseif ($request->filled('image')) {
            $data['image'] = $request->input('image');
        }

        // Map camelCase originalPrice → snake_case original_price
        if ($request->filled('originalPrice')) {
            $data['original_price'] = $request->input('originalPrice');
        }

        $product = Product::create($data);
        return response()->json($product, 201);
    }

    public function update(Request $request, Product $product)
    {
        $request->validate([
            'category'      => 'sometimes|required|string',
            'name'          => 'sometimes|required|string',
            'subtitle'      => 'nullable|string',
            'description'   => 'nullable|string',
            'price'         => 'sometimes|required|numeric',
            'originalPrice' => 'nullable|numeric',
            'badge'         => 'nullable|string',
            'rating'        => 'nullable|numeric',
            'reviews'       => 'nullable|integer',
            'image'         => 'nullable',
        ]);

        $data = $request->only([
            'category', 'name', 'subtitle', 'description',
            'price', 'badge', 'rating', 'reviews',
        ]);

        // Handle image: file upload takes priority over string path
        if ($request->hasFile('image')) {
            $file     = $request->file('image');
            $filename = uniqid('product_') . '.' . $file->getClientOriginalExtension();
            $dest     = public_path('images/products');

            if (!is_dir($dest)) {
                mkdir($dest, 0775, true);
            }

            $file->move($dest, $filename);
            $data['image'] = '/images/products/' . $filename;
        } elseif ($request->has('image')) {
            $data['image'] = $request->input('image');
        }

        // Map camelCase originalPrice → snake_case original_price
        if ($request->has('originalPrice')) {
            $data['original_price'] = $request->input('originalPrice');
        }

        $product->update($data);
        return response()->json($product->fresh());
    }

    public function destroy(Product $product)
    {
        $product->delete();
        return response()->json(null, 204);
    }

    public function reset()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        Product::truncate();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        return response()->json(['message' => 'All products have been cleared.']);
    }
}
