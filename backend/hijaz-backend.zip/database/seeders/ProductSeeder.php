<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\Product;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $products = [
            'oud' => [
                [
                    'name' => 'Athar Al-Oud',
                    'subtitle' => 'Classic Dark Agarwood Attar',
                    'description' => 'A rich, smoky attar distilled from the finest agarwood. Deep, ancient, and utterly captivating.',
                    'price' => 89.00,
                    'image' => '/athar.png',
                    'badge' => 'Best Seller',
                    'rating' => 4.9,
                    'reviews' => 214,
                ],
                [
                    'name' => 'Oud Al-Shams',
                    'subtitle' => 'Smoky Resinous Blend',
                    'description' => 'Sun-kissed resins and dark woods create a scent that lingers like a desert sunset.',
                    'price' => 120.00,
                    'original_price' => 145.00,
                    'image' => '/athar.png',
                    'badge' => 'Sale',
                    'rating' => 4.7,
                    'reviews' => 98,
                ],
                [
                    'name' => 'Amber Noir',
                    'subtitle' => 'Dark Amber & Sandalwood',
                    'description' => 'Warm golden amber entwined with creamy sandalwood for an irresistibly smooth experience.',
                    'price' => 75.00,
                    'image' => '/athar.png',
                    'rating' => 4.6,
                    'reviews' => 73,
                ],
                [
                    'name' => 'Rose Oud',
                    'subtitle' => 'Floral Oud Fusion',
                    'description' => 'The romance of fresh Turkish roses meets the depth of Cambodian oud in this signature blend.',
                    'price' => 95.00,
                    'image' => '/athar.png',
                    'badge' => 'New',
                    'rating' => 4.8,
                    'reviews' => 42,
                ],
                [
                    'name' => 'Oud Royale',
                    'subtitle' => 'Premium Aged Agarwood',
                    'description' => 'A collector\'s attar — aged 12 years in traditional copper vessels for unmatched depth.',
                    'price' => 185.00,
                    'image' => '/athar.png',
                    'badge' => 'Limited',
                    'rating' => 5.0,
                    'reviews' => 31,
                ],
                [
                    'name' => 'Musk Attar',
                    'subtitle' => 'Pure White Musk & Oud',
                    'description' => 'Soft, skin-close white musk elevated with a whisper of oud for everyday elegance.',
                    'price' => 65.00,
                    'image' => '/athar.png',
                    'rating' => 4.5,
                    'reviews' => 156,
                ],
            ],
            'fragrance' => [
                [
                    'name' => 'Rose Crystal',
                    'subtitle' => 'Floral Heart of Rose & Peony',
                    'description' => 'A dazzling faceted crystal bottle holding a vibrant floral heart of rose, peony and soft musk.',
                    'price' => 119.00,
                    'image' => '/perfume.png',
                    'badge' => 'Signature',
                    'rating' => 4.9,
                    'reviews' => 187,
                ],
                [
                    'name' => 'Velvet Bloom',
                    'subtitle' => 'Warm Musk & Jasmine',
                    'description' => 'Velvety jasmine petals resting on a warm musk base — sensual and effortlessly feminine.',
                    'price' => 99.00,
                    'original_price' => 125.00,
                    'image' => '/perfume.png',
                    'badge' => 'Sale',
                    'rating' => 4.7,
                    'reviews' => 112,
                ],
                [
                    'name' => 'Pink Amour',
                    'subtitle' => 'Fresh Citrus & Wild Berries',
                    'description' => 'A sparkling burst of citrus and wild berries that evokes a sun-drenched garden in bloom.',
                    'price' => 85.00,
                    'image' => '/perfume.png',
                    'rating' => 4.6,
                    'reviews' => 88,
                ],
                [
                    'name' => 'Crystal Noir',
                    'subtitle' => 'Dark Rose & Black Pepper',
                    'description' => 'Bold black pepper ignites over a bed of dark roses for a mysteriously seductive signature.',
                    'price' => 135.00,
                    'image' => '/perfume.png',
                    'badge' => 'New',
                    'rating' => 4.8,
                    'reviews' => 34,
                ],
                [
                    'name' => 'Diamond Blush',
                    'subtitle' => 'Powdery Iris & Vanilla',
                    'description' => 'Sheer powdery iris melts into warm Madagascar vanilla — graceful, refined, and timeless.',
                    'price' => 155.00,
                    'image' => '/perfume.png',
                    'badge' => 'Limited',
                    'rating' => 5.0,
                    'reviews' => 19,
                ],
                [
                    'name' => 'Garden Dew',
                    'subtitle' => 'Dewy Florals & Green Tea',
                    'description' => 'Crisp green tea fused with morning-dew florals for a refreshing, nature-inspired fragrance.',
                    'price' => 79.00,
                    'image' => '/perfume.png',
                    'rating' => 4.5,
                    'reviews' => 203,
                ],
            ],
            'bath' => [
                [
                    'name' => 'Cloud Soft Towel Set',
                    'subtitle' => '100% Egyptian Cotton — Set of 4',
                    'description' => 'Hotel-quality Egyptian cotton towels — impossibly soft, fast-drying, and built to last years.',
                    'price' => 69.00,
                    'image' => '/bath1.png',
                    'badge' => 'Best Seller',
                    'rating' => 4.9,
                    'reviews' => 324,
                ],
                [
                    'name' => 'Azure Bath Sheet',
                    'subtitle' => 'Extra-Large Plush Towel',
                    'description' => 'Wrap yourself in extra-large plush comfort. A generously sized bath sheet for a spa experience at home.',
                    'price' => 45.00,
                    'original_price' => 59.00,
                    'image' => '/bath1.png',
                    'badge' => 'Sale',
                    'rating' => 4.8,
                    'reviews' => 178,
                ],
                [
                    'name' => 'Spa Hand Towels',
                    'subtitle' => 'Quick-Dry Waffle Weave',
                    'description' => 'Lightweight waffle-weave hand towels that dry in minutes — perfect for busy bathrooms.',
                    'price' => 29.00,
                    'image' => '/bath1.png',
                    'rating' => 4.6,
                    'reviews' => 241,
                ],
                [
                    'name' => 'Premium Face Cloths',
                    'subtitle' => 'Ultra-Soft Bamboo Blend',
                    'description' => 'Silky bamboo-cotton blend face cloths gentle on skin. Dermatologist-recommended.',
                    'price' => 24.00,
                    'image' => '/bath1.png',
                    'badge' => 'New',
                    'rating' => 4.7,
                    'reviews' => 56,
                ],
                [
                    'name' => 'Hotel Collection Set',
                    'subtitle' => '6-Piece Luxury Bundle',
                    'description' => 'Everything you need for a five-star bathroom experience — 2 bath, 2 hand, 2 face towels.',
                    'price' => 115.00,
                    'image' => '/bath1.png',
                    'badge' => 'Value',
                    'rating' => 5.0,
                    'reviews' => 89,
                ],
                [
                    'name' => 'Organic Bath Robe',
                    'subtitle' => 'GOTS-Certified Organic Cotton',
                    'description' => 'Certified organic cotton robe with deep pockets and a plush shawl collar. Pure indulgence.',
                    'price' => 95.00,
                    'image' => '/bath1.png',
                    'rating' => 4.9,
                    'reviews' => 143,
                ],
            ],
            'bedding' => [
                [
                    'name' => 'Cloud Pillow Pair',
                    'subtitle' => '1000-Thread-Count Long-Staple Cotton',
                    'description' => 'Rest your head on cloud-like comfort — 1000-thread-count long-staple cotton in a crisp sateen weave.',
                    'price' => 89.00,
                    'image' => '/bed.png',
                    'badge' => 'Best Seller',
                    'rating' => 5.0,
                    'reviews' => 412,
                ],
                [
                    'name' => 'Ivory Duvet Set',
                    'subtitle' => 'Sateen Weave — King Size',
                    'description' => 'Transform your bedroom with our king-size sateen duvet. Breathable, lustrous, and endlessly soft.',
                    'price' => 149.00,
                    'original_price' => 199.00,
                    'image' => '/bed.png',
                    'badge' => 'Sale',
                    'rating' => 4.8,
                    'reviews' => 237,
                ],
                [
                    'name' => 'Linen Flat Sheet',
                    'subtitle' => 'Enzyme-Washed Pure Linen',
                    'description' => 'Pre-washed pure linen that gets softer with every wash. Naturally temperature-regulating.',
                    'price' => 79.00,
                    'image' => '/bed.png',
                    'rating' => 4.7,
                    'reviews' => 188,
                ],
                [
                    'name' => 'Pillow Protectors',
                    'subtitle' => 'Anti-Allergy Breathable Cover',
                    'description' => 'Invisible anti-allergy barrier that protects pillows while remaining completely breathable.',
                    'price' => 35.00,
                    'image' => '/bed.png',
                    'badge' => 'New',
                    'rating' => 4.6,
                    'reviews' => 67,
                ],
                [
                    'name' => 'Full Bedroom Bundle',
                    'subtitle' => 'Sheet Set + 4 Pillows + Duvet',
                    'description' => 'The ultimate bedroom upgrade — everything you need for the perfect night\'s sleep, bundled together.',
                    'price' => 299.00,
                    'image' => '/bed.png',
                    'badge' => 'Bundle',
                    'rating' => 5.0,
                    'reviews' => 55,
                ],
                [
                    'name' => 'Bamboo Fitted Sheet',
                    'subtitle' => 'Temperature-Regulating',
                    'description' => 'Stay cool in summer, warm in winter with our innovative bamboo-derived fitted sheet.',
                    'price' => 65.00,
                    'image' => '/bed.png',
                    'rating' => 4.8,
                    'reviews' => 302,
                ],
            ],
        ];

        foreach ($products as $category => $list) {
            foreach ($list as $prod) {
                Product::create(array_merge($prod, ['category' => $category]));
            }
        }
    }
}
